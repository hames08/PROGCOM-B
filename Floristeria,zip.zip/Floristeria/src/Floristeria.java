package floristeria;

public class Floristeria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("  INICIALIZACIÓN DE FLORISTERÍA CARLITOS");
        
        
        FloristeriaCarlitos miFloristeria = new FloristeriaCarlitos();
        
        System.out.println(" ESTADO INICIAL");
        System.out.println(miFloristeria.describir());
        
        // Llama al método sobrescrito. Actualiza: Casa.color Y FloristeriaCarlitos.colorFachada aunque esto no se ejecuta  sale error porque el color de la fachada es privado, me di cuenta de ese error
        miFloristeria.pintar("Verde Oliva"); 
        
        // Llama a métodos propios de la Floristería
        miFloristeria.pintarLaterales("Rosa Pastel");
        miFloristeria.pintarPuerta("Negro Carbón");

        
        System.out.println("\n ESTADO FINAL DESPUÉS DE PINTAR ");
        System.out.println("Color LATERAL: " + miFloristeria.getColorLateral());
        System.out.println("Color PUERTA: " + miFloristeria.getColorPuerta());
        
        System.out.println("\n DESCRIPCIÓN FINAL ");
        // El método describir() sobrescrito usará los nuevos colores
        System.out.println(miFloristeria.describir());
    }


	}


