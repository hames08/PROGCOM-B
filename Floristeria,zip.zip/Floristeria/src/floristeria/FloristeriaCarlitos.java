package floristeria;

public class FloristeriaCarlitos extends Casa {
	 private String colorFachada;
	    private String colorLateral;
	    private String colorPuerta;
	    private String materialTecho;
	    private String logo;
	    private int totalFloresInterior;
	    private int totalFloresExterior;
	    private double anchoPuerta;
	    private double altoPuerta;
	    private String materialPuerta;
	    private String colorTecho;
	    private String patronTecho;
	    private int totalTejas;
	    private String colorBase;
	    private String inicialesBase;
	    private double alturaPasto;
	    private double altoTitulo;
	    private double anchoTitulo;


	    public FloristeriaCarlitos() {
	        super("Amarillo", 1, 1, true, false); 

	        // Inicializa atributos propios
	        this.colorFachada = "Blanco"; // Color visible de la fachada este atributo es privado  no se puede cambiar
	        this.colorLateral = "N/A (Ver detalles en describir)";
	        this.colorPuerta = "Marrón";
	        this.materialPuerta = "Madera con marco Marrón";
	        this.materialTecho = "Cartulina";
	        this.colorTecho = "Rojo";
	        this.patronTecho = "Cuadrícula";
	        this.totalTejas = 48;
	        this.colorBase = "Blanco";
	        this.inicialesBase = "HDEG";
	        this.alturaPasto = 1.4;
	        this.logo = "Florería (Negro)";
	        this.altoTitulo = 1.3;
	        this.anchoTitulo = 5.5;
	        this.anchoPuerta = 4.4;
	        this.altoPuerta = 2.3;
	        this.totalFloresInterior = 1;
	        this.totalFloresExterior = 27; // Total: 27
	    }

	    /**
	     * Sobrescribe el método describir() de la clase Casa para dar la descripción.
	     */
	    @Override
	    public String describir() {

	        String desc = " Descripción de la Floristería Carlitos \n\n";
	        
	      
	        desc += " BASE y PASTO \n";
	        desc += "Base: Color " + this.colorBase + " (" + 6.8 + " cm x " + 5.0 + " cm). Iniciales: " + this.inicialesBase + " (Negro).\n";
	        desc += "Pasto: Verde, altura " + this.alturaPasto + " cm en todas las fachadas.\n\n";
	        desc += " TECHO \n";
	        desc += "Techo: De " + this.materialTecho + ", color " + this.colorTecho + ", patrón " + this.patronTecho + ".\n";
	        desc += "Total de Tejas: " + this.totalTejas + ".\n\n";
	        desc += " PARTE FRONTAL \n";
	        desc += "Color de la Pared: " + this.colorFachada + ".\n";
	        desc += " Título: '" + this.logo + "'.\n";
	        desc += " Puerta Principal: Color " + this.colorPuerta + " (" + this.anchoPuerta + " cm x " + this.altoPuerta + " cm).\n";
	        desc += " Flores Frontales: 2 Girasoles.\n\n";
	        desc += " Resumen General de Flores\n";
	        desc += " Flores Interiores (Total " + this.totalFloresInterior + "): 1 unidad (Tulipán).\n";
	        desc += " Flores Exteriores (Total " + this.totalFloresExterior + "): 27 unidades (Girasoles, Tulipanes, Rojas, Moradas).\n";

	        return desc;
	    }

	    /**
	     * Sobrescribe el método pintar() de la clase Casa.
	     */
	    @Override
	    public void pintar(String nuevoColor) {
	        super.pintar(nuevoColor); // 
	        this.colorFachada = nuevoColor; 
	        System.out.println(" La FACHADA PRINCIPAL de la floristería ha sido pintada de color " + nuevoColor);
	    }
	    
	    
	    public void pintarLaterales(String nuevoColor) {
	        this.colorLateral = nuevoColor;
	        System.out.println(" Las fachadas LATERALES han sido pintadas de color " + nuevoColor);
	    }
	    
	    
	    public void pintarPuerta(String nuevoColor) {
	        this.colorPuerta = nuevoColor;
	        System.out.println(" La PUERTA ha sido pintada de color " + nuevoColor);
	    }
	    

	    public String getColorLateral() {
	        return colorLateral;
	    }

	    public String getColorPuerta() {
	        return colorPuerta;
	    }
	}


