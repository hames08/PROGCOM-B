package floristeria;

public class main {

	public static void main(String[] args) {
		Casa hamesCasa=new Casa("Blanca",3,2,true,true);
		System.out.println(hamesCasa.describir());
		hamesCasa.pintar("Le agrego el T1.");
		System.out.println(hamesCasa.describir());
	}

}


