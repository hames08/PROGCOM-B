import java.util.*;
import java.lang.*;
import java.io.*;

// The main method must be in a class named "Main".
class Main {
    public static void main(String[] args) {

        Scanner leer=new Scanner(System.in);
        System.out.println("Ingresa tu calificación: ");
            int calificacion=leer.nextInt();

        //Con operador terniario
        String mensaje0=(calificacion >= 60)?"Aprobado":"Reprobado";
        System.out.println(mensaje0);

        //Con if else
        String mensaje1="";
        if (calificacion >= 60) {
            mensaje1=("Aprobado");
        } else {
            mensaje1=("Reprobado");
        }  
        System.out.println(mensaje1);

        //Con if-else if
        String mensaje2="";
        if (calificacion<0 || calificacion>100) {
            mensaje2=("Calificación inválida");
        } else if (calificacion >= 60) {
            mensaje2=("Aprobado");
        } else {
            mensaje2=("Reprobado");
        }
        System.out.println(mensaje2);
    }
}