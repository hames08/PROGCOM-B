import java.util.*;
import java.lang.*;
import java.io.*;

// The main method must be in a class named "Main".
class Main {
    public static void main(String[] args) {
        
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese el primer número: ");
            int numero1=leer.nextInt();

        System.out.println("Ingrese el segundo número: ");
            int numero2=leer.nextInt();

        //Con operador terniario
        String mensaje0=(numero1 > numero2)? ("El mayor es: " + numero1):("El mayor es: " + numero2);
        System.out.println(mensaje0);

        //Con if else
        String mensaje1="";
        if (numero1 > numero2) {
            mensaje1=("El mayor es: " + numero1);
        } else {
            mensaje1=("El mayor es: " + numero2);
        }
        System.out.println(mensaje1);

        //Con if-else if
        String mensaje2="";
        if (numero1 > numero2) {
            mensaje2=("El mayor es: " + numero1);
        } else if (numero2 > numero1) {
            mensaje2=("El mayor es: " + numero2);
        }
        System.out.println(mensaje2);
    }
}