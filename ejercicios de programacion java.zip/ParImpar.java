import java.util.*;
import java.lang.*;
import java.io.*;

// The main method must be in a class named "Main".
class Main {
    public static void main(String[] args) {

        Scanner leer=new Scanner(System.in);
        System.out.print("Ingrese un número: ");
        int numero= leer.nextInt();

        //Con operador terniario
        String mensaje0=(numero%2==0)? (numero + " es par"):(numero + " es impar");
        System.out.println(mensaje0);

        //Con if else
        String mensaje1="";
        if (numero%2==0) {
            mensaje1=(numero + " es par");
        } else {
            mensaje1=(numero + " es impar");
        }
        System.out.println(mensaje1);

        //Con if-else if
        String mensaje2="";
        if (numero%2==0) {
            mensaje2=(numero + " es par");
        } else if (numero%2!=0) {
            mensaje2=(numero + " es impar");
        }
        System.out.println(mensaje2);
    }
}