import java.util.*;
import java.lang.*;
import java.io.*;

// The main method must be in a class named "Main".
class Main {
    public static void main(String[] args) {

        Scanner leer=new Scanner(System.in);
        System.out.println("Ingresa tu edad: ");
            int edad=leer.nextInt();

        //Con operador terniario
        String mensaje0=(edad>=18)?"Eres mayor de edad.":"Eres menor de edad.";
        System.out.println(mensaje0);

        //Con if else
        String mensaje1="";
        if (edad>=18){
            mensaje1="Eres mayor de edad.";
        } else {
            mensaje1="Eres menor de edad.";
        }
        System.out.println(mensaje1);

        //Con if-else if
        String mensaje2="";
        if (edad>=18){
            mensaje2="Eres mayor de edad.";
        } else if (edad<18) {
            mensaje2="Eres menor de edad.";
        }
        System.out.println(mensaje2);
    }
}