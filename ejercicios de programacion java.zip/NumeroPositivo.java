import java.util.*;
import java.lang.*;
import java.io.*;


// The main method must be in a class named "Main".
class Main {
    public static void main(String[] args) {

        Scanner leer=new Scanner(System.in);
        System.out.println("Ingresa un número: ");
        int numero=leer.nextInt();

        //Con operador terniario
        String mensaje0 = (numero < 0) ? (numero + " es negativo") : (numero + " es positivo");
        System.out.println(mensaje0);
        
        //Con if else
        String mensaje1="";
        if (numero < 0) {
            mensaje1=(numero + " es negativo");
        } else {
            mensaje1=(numero + " es positivo");
        } 
        System.out.println(mensaje1);
       
        //Con if-else if
        String mensaje2="";
        if (numero < 0) {
            mensaje2=(numero + " es negativo");
        } else if (numero > 0) {
            mensaje2=(numero + " es positivo");
        } 
        System.out.println(mensaje2);           
    }
}